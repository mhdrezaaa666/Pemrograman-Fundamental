class Main {
  public static void main(String[] args) {
    // Inisialisasi variabel dengan tipe data String
    String nama = "Budi";				// Teks biasa
    String tanya = "Apa " + "kabar?";	// Gabung 2 teks
    String sapa = "Hai " + "Budi";		// Gabung teks dan variabel 
    String kalimat = sapa + ", " + tanya; 	// Gabungan semuanya
    System.out.println(kalimat);
    
    // Cetak variabel kalimat
    
  }
}